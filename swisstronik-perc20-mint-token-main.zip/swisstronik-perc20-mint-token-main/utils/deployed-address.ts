const deployedAddress = '0xCd825ae0335190f4c8882DF16FB0577d478b3898'

export default deployedAddress
